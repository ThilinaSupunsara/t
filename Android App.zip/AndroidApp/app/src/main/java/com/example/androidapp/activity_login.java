package com.example.androidapp;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activity_login extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.editTextUsername);
        passwordEditText = findViewById(R.id.editTextPassword);
        loginButton = findViewById(R.id.buttonLogin);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Replace the following condition with your actual authentication logic
                if (isValidLogin(usernameEditText.getText().toString(), passwordEditText.getText().toString())) {
                    // Successful login, navigate to the next screen
                    Intent intent = new Intent(activity_login.this, UserListActivity.class);
                    startActivity(intent);
                } else {
                    // Display a warning for unsuccessful login
                    // You can use a Toast or any other UI element to show a warning message
                    Toast.makeText(activity_login.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Replace this with your actual authentication logic
    private boolean isValidLogin(String username, String password) {
        // Add your authentication logic here
        // For simplicity, this example always returns true
        return true;
    }
}